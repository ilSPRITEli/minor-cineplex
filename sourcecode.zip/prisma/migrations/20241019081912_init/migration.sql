-- AlterTable
ALTER TABLE "Movie" ADD COLUMN     "outDate" TIMESTAMP(3);
